package repository

import (
 "context"
 "errors"
 "fmt"
 "strings"
 "secure-gin-api/model"
 "github.com/jackc/pgx/v5"
 "github.com/jackc/pgx/v5/pgxpool"
)
var ErrNotFound=errors.New("employee not found")
type EmployeeRepository struct{ DB *pgxpool.Pool }
func NewEmployeeRepository(db *pgxpool.Pool)*EmployeeRepository{return &EmployeeRepository{DB:db}}
func (r *EmployeeRepository) Create(ctx context.Context,e model.EmployeeInput)(model.Employee,error){ var out model.Employee; err:=r.DB.QueryRow(ctx,`INSERT INTO employees(name,email,age,salary) VALUES($1,$2,$3,$4) RETURNING id,name,email,age,salary,created_at::text`,strings.TrimSpace(e.Name),strings.TrimSpace(e.Email),e.Age,e.Salary).Scan(&out.ID,&out.Name,&out.Email,&out.Age,&out.Salary,&out.CreatedAt);return out,err }
func (r *EmployeeRepository) Get(ctx context.Context,id int64)(model.Employee,error){var e model.Employee;err:=r.DB.QueryRow(ctx,`SELECT id,name,email,age,salary,created_at::text FROM employees WHERE id=$1`,id).Scan(&e.ID,&e.Name,&e.Email,&e.Age,&e.Salary,&e.CreatedAt);if errors.Is(err,pgx.ErrNoRows){return e,ErrNotFound};return e,err}
func (r *EmployeeRepository) List(ctx context.Context,page,limit int,sort,order string)([]model.Employee,int,error){ allowed:=map[string]string{"name":"name","email":"email","age":"age","salary":"salary","id":"id"}; col,ok:=allowed[sort];if !ok{col="id"};dir:="ASC";if strings.EqualFold(order,"desc"){dir="DESC"};var total int;if err:=r.DB.QueryRow(ctx,"SELECT count(*) FROM employees").Scan(&total);err!=nil{return nil,0,err};q:=fmt.Sprintf(`SELECT id,name,email,age,salary,created_at::text FROM employees ORDER BY %s %s LIMIT $1 OFFSET $2`,col,dir);rows,err:=r.DB.Query(ctx,q,limit,(page-1)*limit);if err!=nil{return nil,0,err};defer rows.Close();out:=[]model.Employee{};for rows.Next(){var e model.Employee;if err=rows.Scan(&e.ID,&e.Name,&e.Email,&e.Age,&e.Salary,&e.CreatedAt);err!=nil{return nil,0,err};out=append(out,e)};return out,total,rows.Err()}
func (r *EmployeeRepository) Update(ctx context.Context,id int64,e model.EmployeeInput)(model.Employee,error){var out model.Employee;err:=r.DB.QueryRow(ctx,`UPDATE employees SET name=$1,email=$2,age=$3,salary=$4,updated_at=now() WHERE id=$5 RETURNING id,name,email,age,salary,created_at::text`,strings.TrimSpace(e.Name),strings.TrimSpace(e.Email),e.Age,e.Salary,id).Scan(&out.ID,&out.Name,&out.Email,&out.Age,&out.Salary,&out.CreatedAt);if errors.Is(err,pgx.ErrNoRows){return out,ErrNotFound};return out,err}
func (r *EmployeeRepository) Delete(ctx context.Context,id int64)error{tag,err:=r.DB.Exec(ctx,`DELETE FROM employees WHERE id=$1`,id);if err!=nil{return err};if tag.RowsAffected()==0{return ErrNotFound};return nil}
type User struct{ID int64; Username,PasswordHash,Role string}
func (r *EmployeeRepository) FindUser(ctx context.Context,username string)(User,error){var u User;err:=r.DB.QueryRow(ctx,`SELECT id,username,password_hash,role FROM users WHERE username=$1`,username).Scan(&u.ID,&u.Username,&u.PasswordHash,&u.Role);return u,err}
