package model

type Employee struct { ID int64 `json:"id"`; Name string `json:"name"`; Email string `json:"email"`; Age int `json:"age"`; Salary float64 `json:"salary"`; CreatedAt string `json:"created_at,omitempty"` }
type EmployeeInput struct { Name string `json:"name"`; Email string `json:"email"`; Age int `json:"age"`; Salary float64 `json:"salary"` }
type LoginInput struct { Username string `json:"username"`; Password string `json:"password"` }
