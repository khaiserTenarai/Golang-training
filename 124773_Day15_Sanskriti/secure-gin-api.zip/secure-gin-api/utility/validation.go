package utility

import (
 "fmt"
 "net/mail"
 "strings"
 "secure-gin-api/model"
)
func ValidateEmployee(e model.EmployeeInput)error{if strings.TrimSpace(e.Name)==""{return fmt.Errorf("name is required")};if len(e.Name)>100{return fmt.Errorf("name must be at most 100 characters")};if _,err:=mail.ParseAddress(e.Email);err!=nil{return fmt.Errorf("valid email is required")};if e.Age<18||e.Age>120{return fmt.Errorf("age must be between 18 and 120")};if e.Salary<0{return fmt.Errorf("salary cannot be negative")};return nil}
