module secure-gin-api

go 1.23

require (
 github.com/gin-gonic/gin v1.10.0
 github.com/golang-jwt/jwt/v5 v5.2.1
 github.com/google/uuid v1.6.0
 github.com/jackc/pgx/v5 v5.7.2
 github.com/joho/godotenv v1.5.1
 golang.org/x/crypto v0.31.0
)
