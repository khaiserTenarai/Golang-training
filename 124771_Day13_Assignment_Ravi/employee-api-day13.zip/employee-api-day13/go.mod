module employee-api-day13

go 1.23

require github.com/jackc/pgx/v5 v5.7.2
