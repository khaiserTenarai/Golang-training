# Day 13 — Configurable Employee API (Go + net/http + PostgreSQL)

This project implements the Day 13 checklist in one project, without Gin.

## Requirements
- Go 1.23+ (or a compatible newer Go version)
- PostgreSQL
- Dependencies downloaded with `go mod tidy`

## Setup
1. Create a PostgreSQL database:
   ```sql
   CREATE DATABASE employee_api;
   ```
2. Copy `.env.example` to `.env` and set your database credentials.
3. Install dependencies:
   ```bash
   go mod tidy
   ```
4. Run:
   ```bash
   go run .
   ```
The app creates the `employees` table at startup.

## Environment modes
Set `APP_ENV` to `development`, `test`, or `production`.
- `development`: default values are allowed and logs are readable.
- `test`: use a separate test database and set explicit test credentials.
- `production`: database password is required; default secrets are never provided.

This small example reads `.env` itself (without a dotenv dependency). Existing process environment variables take precedence over `.env`.

## Endpoints
- `GET /health`
- `GET /employees`
- `GET /employees/{id}`
- `POST /employees` (can be disabled with `FEATURE_CREATE_EMPLOYEE=false`)
- `PUT /employees/{id}`
- `DELETE /employees/{id}`

Example create request:
```bash
curl -X POST http://localhost:8080/employees \
  -H "Content-Type: application/json" \
  -d '{"name":"Ravi Ranjan","email":"ravi@example.com","department":"Engineering"}'
```

## Task map
- Tasks 1–4: `config/config.go` — env loading, `Config` struct, validation, defaults.
- Tasks 5–7: `config/config.go` — development/test/production environment behavior.
- Task 8: `.env.example`, `config/config.go`, and `database/postgres.go` — secrets are environment-provided and not hard-coded; do not commit `.env`.
- Task 9: `main.go` — `http.Server.Shutdown`.
- Task 10: `main.go` — `signal.NotifyContext` for SIGINT/SIGTERM.
- Task 11: `controller/employee_controller.go`, `service/employee_service.go`, `repository/postgres_repository.go` — contexts are passed down to DB calls.
- Task 12: `main.go` — ordered startup initialization.
- Task 13: `main.go` — ordered shutdown and pool close.
- Task 14: `config/config.go` and `controller/employee_controller.go` — feature flag.
- Task 15: entire application.

## Notes
- This is a learning project, not a production security blueprint.
- In production, use a secret manager or deployment secret injection instead of storing real secrets in files.
- Use a separate PostgreSQL database for tests.
- For the route pattern `/employees/{id}`, Go 1.22+ `net/http` routing is used.
