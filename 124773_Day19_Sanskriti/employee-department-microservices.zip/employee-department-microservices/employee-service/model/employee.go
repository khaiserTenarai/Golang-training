package model

type Employee struct {
	ID           int
	Name         string
	Email        string
	DepartmentID int
}
