module employee-department-microservices

go 1.22

require github.com/gin-gonic/gin v1.10.0
