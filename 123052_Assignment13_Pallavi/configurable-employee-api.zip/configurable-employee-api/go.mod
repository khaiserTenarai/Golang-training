module configurable-employee-api

go 1.21

require github.com/golang-jwt/jwt/v5 v5.3.1 // indirect
